package br.com.dextraining.domain;

public class Login {
   private String usuario;
   private String senha;
   private String mensagem = "teste";
   
   public String verificaLogin(){
       if (usuario.equals("user")){
           if (senha.equals("user")){ 
               mensagem = "Bem Vindo " + usuario;
           }else{
               mensagem = "Senha Inválida";
           }
       }else {
           mensagem = "Usuário " + usuario + " não faz parte do sistema";
       }
       return null;
   }

   public String getUsuario() {
       return usuario;
   }

   public void setUsuario(String usuario) {
       this.usuario = usuario;
   }

   public String getSenha() {
       return senha;
   }

   public void setSenha(String senha) {
       this.senha = senha;
   }

   public String getMensagem() {
       return mensagem;
   }

   public void setMensagem(String mensagem) {
       this.mensagem = mensagem;
   }

   
}