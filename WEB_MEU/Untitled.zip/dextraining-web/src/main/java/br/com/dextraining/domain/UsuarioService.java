package br.com.dextraining.domain;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "UsuarioService")
public class UsuarioService {
	
	private static List<Usuario> usuarios = new ArrayList<>();
	
	
	public static boolean logar(Usuario usuario) {
		if (usuario.getLogin().equals("user") && usuario.getSenha().equals("user")) {
			return true;
		}
		return false;
	}


	public static List<Usuario> listar() {
		
		return null;
	}

}

