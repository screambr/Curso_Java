package br.com.dextraining.web.controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.dextraining.domain.Usuario2;



@ManagedBean
@ViewScoped
public class LoginBean {

    private Usuario2 usuario = new Usuario2();

    public Usuario2 getUsuario() {
        return usuario;
    }

    /**
     * Funcao para verificar se o usuario existe realmente ou nao, caso nao seja encontrado 
     * o sistema enviara uma mensagem alertando ao usuario.
     * @return Usuario
     */
    public String efetuaLogin() {
        System.out.println("Fazendo login do usuário " + this.usuario.getUsuario());

        return "livro?faces-redirect=true";
    }

}